<div class="sidebar-video-block">
	<h4><?php _e('Ready Made Sites', 'multiple-pages-generator-by-porthas') ?></h4>
	<ul class=" ">
		<li>
			<a href="https://docs.themeisle.com/article/2069-currency-converter-demosite" class=" btn btn-link btn-site-link" target="_blank" rel="noreferrer"><?php _e('Currency Converter', 'multiple-pages-generator-by-porthas'); ?> <span class="text-decoration-none dashicons dashicons-external"></span></a>
		</li>
		<li>
			<a href="https://docs.themeisle.com/article/2073-real-estate-listing" target="_blank" class=" btn btn-link btn-site-link" rel="noreferrer"><?php _e('Real Estates', 'multiple-pages-generator-by-porthas'); ?> <span class=" text-decoration-none dashicons dashicons-external"></span></a>
		</li>
		<li>
			<a href="https://docs.themeisle.com/article/2072-hotels-demosite" target="_blank" class=" btn btn-link btn-site-link" rel="noreferrer"><?php _e('Hotels', 'multiple-pages-generator-by-porthas'); ?> <span class=" text-decoration-none dashicons dashicons-external"></span></a>
		</li>
		<li>
			<a href="https://docs.themeisle.com/article/2070-jobs-listing-demosite" target="_blank" class=" btn btn-link btn-site-link" rel="noreferrer"><?php _e('Jobs listing', 'multiple-pages-generator-by-porthas'); ?> <span class=" text-decoration-none dashicons dashicons-external"></span></a>
		</li>
	</ul>
</div>