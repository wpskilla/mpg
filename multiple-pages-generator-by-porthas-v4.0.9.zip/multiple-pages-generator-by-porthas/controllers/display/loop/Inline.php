<?php
namespace MPG\Display\Loop;

use MPG\Display\Loop\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Class Inline
 *
 * @package MPG\Display\Core
 */
class Inline extends Core {

	/**
	 * Registers the shortcode.
	 */
	public function register(){

	}

}