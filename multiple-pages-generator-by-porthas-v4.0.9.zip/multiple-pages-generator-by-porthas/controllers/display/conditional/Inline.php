<?php
namespace MPG\Display\Conditional;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Class Inline
 *
 * @package MPG\Display\Conditional
 */
class Inline extends Core {

	/**
	 * Registers the shortcode.
	 */
	public function register(){

	}

}