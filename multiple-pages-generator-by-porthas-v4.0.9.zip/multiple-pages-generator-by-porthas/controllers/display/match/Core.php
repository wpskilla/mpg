<?php

namespace MPG\Display\Match;

use MPG\Display\Base_Display;
use MPG\Display\Loop\Core as Loop_Core;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Core
 *
 * @package MPG\Display\Match
 */
abstract class Core extends Loop_Core {
}