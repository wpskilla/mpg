<?php

namespace Box\Spout\Writer\Exception;

/**
 * Class SheetNotFoundException
 */
class SheetNotFoundException extends WriterException
{
}
