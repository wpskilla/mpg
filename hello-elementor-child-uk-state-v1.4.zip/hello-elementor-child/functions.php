<?php


// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );
         
if ( !function_exists( 'child_theme_configurator_css' ) ):
    function child_theme_configurator_css() {
        wp_enqueue_style( 'chld_thm_cfg_child', trailingslashit( get_stylesheet_directory_uri() ) . 'style.css', array( 'hello-elementor','hello-elementor','hello-elementor-theme-style','hello-elementor-header-footer' ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'child_theme_configurator_css', 99 );

// END ENQUEUE PARENT ACTION


// ========================
// BASIC SECURITY MEASURES
// ========================

// Disable file editing from WordPress dashboard
// define('DISALLOW_FILE_EDIT', true);

// Limit post revisions to reduce database bloat
define('WP_POST_REVISIONS', 2);

// ========================
// REST API SECURITY
// ========================

// Disable REST API for non-authenticated users
add_filter('rest_authentication_errors', function($result) {
    if (!empty($result)) {
        return $result;
    }
    if (!is_user_logged_in()) {
        return new WP_Error('rest_not_logged_in', 'REST API is available only for authenticated users.', array('status' => 401));
    }
    return $result;
});

// Disable REST API user endpoints (prevents username enumeration)
add_filter('rest_endpoints', function($endpoints) {
    if (isset($endpoints['/wp/v2/users'])) {
        unset($endpoints['/wp/v2/users']);
    }
    if (isset($endpoints['/wp/v2/users/(?P<id>[\d]+)'])) {
        unset($endpoints['/wp/v2/users/(?P<id>[\d]+)']);
    }
    return $endpoints;
});

// ========================
// XML-RPC SECURITY
// ========================

// Disable XML-RPC completely (if you don't need it)
add_filter('xmlrpc_enabled', '__return_false');

// Alternatively, disable only pingbacks if you need XML-RPC for other functions
add_filter('xmlrpc_methods', function($methods) {
    unset($methods['pingback.ping']);
    return $methods;
});

// ========================
// HEADER SECURITY
// ========================

// Remove WordPress version info from head and feeds
remove_action('wp_head', 'wp_generator');
add_filter('the_generator', '__return_empty_string');

// Remove Really Simple Discovery link
remove_action('wp_head', 'rsd_link');

// Remove WLManifest link (Windows Live Writer)
remove_action('wp_head', 'wlwmanifest_link');

// Remove shortlink
remove_action('wp_head', 'wp_shortlink_wp_head');

// Disable emoji scripts
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('admin_print_scripts', 'print_emoji_detection_script');
remove_action('admin_print_styles', 'print_emoji_styles');

// Security headers
function add_security_headers() {
    // Prevent clickjacking
    header('X-Frame-Options: SAMEORIGIN');
    
    // Enable XSS protection
    header('X-XSS-Protection: 1; mode=block');
    
    // Prevent MIME type sniffing
    header('X-Content-Type-Options: nosniff');
    
    // Referrer policy
    header('Referrer-Policy: strict-origin-when-cross-origin');
    
    // Content Security Policy (adjust based on your needs)
    // header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https:; img-src 'self' https: data:; style-src 'self' 'unsafe-inline' https:; font-src 'self' https: data:;");
}
add_action('send_headers', 'add_security_headers');

// ========================
// LOGIN PAGE SECURITY
// ========================

// Disable login error messages (prevents username enumeration)
add_filter('login_errors', function() {
    return __('Invalid credentials', 'hello-elementor');
});

// Add reCAPTCHA to login form (requires reCAPTCHA keys)
// function add_recaptcha_to_login() {
//     echo '<div class="g-recaptcha" data-sitekey="YOUR_SITE_KEY"></div>';
// }
// add_action('login_form', 'add_recaptcha_to_login');

// function verify_recaptcha_on_login($user, $password) {
//     if (isset($_POST['g-recaptcha-response'])) {
//         $response = wp_remote_post('https://www.google.com/recaptcha/api/siteverify', [
//             'body' => [
//                 'secret'   => 'YOUR_SECRET_KEY',
//                 'response' => $_POST['g-recaptcha-response'],
//                 'remoteip' => $_SERVER['REMOTE_ADDR']
//             ]
//         ]);
        
//         if (is_wp_error($response) || empty($response['body']) || !($json = json_decode($response['body'])) || !$json->success) {
//             wp_die(__('<strong>ERROR</strong>: reCAPTCHA verification failed.', 'hello-elementor'));
//         }
//     } else {
//         wp_die(__('<strong>ERROR</strong>: Please complete the reCAPTCHA.', 'hello-elementor'));
//     }
//     return $user;
// }
// add_filter('wp_authenticate_user', 'verify_recaptcha_on_login', 10, 2);

// ========================
// FILE ACCESS SECURITY
// ========================

// Prevent access to .htaccess, .htpasswd, readme.html, wp-config.php, etc.
function restrict_file_access() {
    if (preg_match('/\.(htaccess|htpasswd|ini|log|sh|sql|env|gitignore|gitattributes|svn|bak|swp|conf|DS_Store|DS_Store?|._.*|Spotlight-V100|TemporaryItems|Trashes|TemporaryItems|__MACOSX)$/i', $_SERVER['REQUEST_URI'])) {
        status_header(403);
        die('Access Forbidden');
    }
    
    if (preg_match('/(readme|license|changelog|wp-config|wp-admin\/install)\.(html|md|txt|php)$/i', $_SERVER['REQUEST_URI'])) {
        status_header(403);
        die('Access Forbidden');
    }
}
add_action('init', 'restrict_file_access');

// ========================
// MISCELLANEOUS SECURITY
// ========================

// Disable directory listing
if (!defined('FS_CHMOD_DIR')) {
    define('FS_CHMOD_DIR', (0755 & ~ umask()));
}

// Disable automatic updates (manage updates manually for better control)
define('AUTOMATIC_UPDATER_DISABLED', true);

// Disable plugin/theme installation and updates from dashboard (optional)
// define('DISALLOW_FILE_MODS', true);

// Disable author scans (username enumeration)
if (!is_admin() && isset($_GET['author'])) {
    wp_redirect(home_url());
    exit;
}

// Remove version info from scripts and styles
// function remove_version_from_assets($src) {
//     if (strpos($src, 'ver=')) {
//         $src = remove_query_arg('ver', $src);
//     }
//     return $src;
// }
// add_filter('style_loader_src', 'remove_version_from_assets', 9999);
// add_filter('script_loader_src', 'remove_version_from_assets', 9999);

// ========================
// DATABASE SECURITY
// ========================

// Change the WordPress database prefix (if not already done during installation)
// Note: This should be done during installation or via a migration tool
// $table_prefix = 'wp_rand0m_';

// ========================
// ADMIN SECURITY
// ========================

// Limit login attempts (consider using a plugin like Wordfence for more robust protection)
function check_login_attempts($user, $username, $password) {
    if (get_transient('login_attempts_' . $_SERVER['REMOTE_ADDR']) >= 5) {
        return new WP_Error('too_many_attempts', __('Too many login attempts. Please try again later.', 'hello-elementor'));
    }
    return $user;
}
add_filter('authenticate', 'check_login_attempts', 30, 3);
//
function track_login_attempts($username, $error) {
    if ($error instanceof WP_Error) {
        $attempts = get_transient('login_attempts_' . $_SERVER['REMOTE_ADDR']) ?: 0;
        set_transient('login_attempts_' . $_SERVER['REMOTE_ADDR'], $attempts + 1, HOUR_IN_SECONDS);
    }
}
add_action('wp_login_failed', 'track_login_attempts', 10, 2);

function clear_login_attempts_on_success($username, $user) {
    delete_transient('login_attempts_' . $_SERVER['REMOTE_ADDR']);
}
add_action('wp_login', 'clear_login_attempts_on_success', 10, 2);

// ========================
// FILE UPLOAD SECURITY
// ========================

// Restrict file upload types
function restrict_mime_types($mimes) {
    $mimes = array(
        'jpg|jpeg|jpe' => 'image/jpeg',
        'gif'           => 'image/gif',
        'png'           => 'image/png',
        'webp'         => 'image/webp',
        'pdf'           => 'application/pdf',
        'doc'           => 'application/msword',
        'docx'          => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'ppt'           => 'application/vnd.ms-powerpoint',
        'pptx'          => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'xls'           => 'application/vnd.ms-excel',
        'xlsx'          => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'zip'           => 'application/zip'
    );
    return $mimes;
}
add_filter('upload_mimes', 'restrict_mime_types');

// ========================
// COMMENTS SECURITY
// ========================

// Disable comments on media attachments
function filter_media_comment_status($open, $post_id) {
    $post = get_post($post_id);
    if ($post->post_type == 'attachment') {
        return false;
    }
    return $open;
}
add_filter('comments_open', 'filter_media_comment_status', 10, 2);

// ========================
// CORE FUNCTIONALITY
// ========================


// ================================
//  customization
// ================================

// mpg pro
add_filter( 'product_mpg_license_status', function( $status ) {
    return 'valid'; // forces premium
}, 999 );

if ( ! defined( 'MPG_PRO_LOADED' ) ) {
    define( 'MPG_PRO_LOADED', true );
}

// remove watermark
function add_custom_script_to_front_page_footer() {
    if ( !is_admin() ) {
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function($){
                jQuery("body > a").remove();
            });
        </script>
        <?php
    }
}
add_action('wp_footer', 'add_custom_script_to_front_page_footer');


// Define your location dataset
$prohandymen_locations = [
    'England' => [
        'Bedfordshire' => ['Ampthill', 'Arlesey', 'Aspley Guise', 'Bedford', 'Biggleswade', 'Dunstable', 'Flitwick', 'Kempston', 'Leighton Buzzard', 'Luton', 'Sandy', 'Shefford', 'Woburn'],
        'Berkshire' => ['Ascot', 'Bracknell', 'Crowthorne', 'Hungerford', 'Maidenhead', 'Newbury', 'Reading', 'Sandhurst', 'Slough', 'Thatcham', 'Windsor', 'Wokingham'],
        'Buckinghamshire' => ['Amersham', 'Aylesbury', 'Beaconsfield', 'Buckingham', 'Chesham', 'High Wycombe', 'Marlow', 'Milton Keynes', 'Newport Pagnell', 'Olney', 'Princes Risborough', 'Winslow'],
        'Cambridgeshire' => ['Cambridge', 'Chatteris', 'Ely', 'Huntingdon', 'March', 'Peterborough', 'St Ives', 'St Neots', 'Wisbech'],
        'Cheshire' => ['Altrincham', 'Chester', 'Congleton', 'Crewe', 'Ellesmere Port', 'Knutsford', 'Macclesfield', 'Middlewich', 'Nantwich', 'Northwich', 'Runcorn', 'Sandbach', 'Warrington', 'Widnes', 'Wilmslow', 'Winsford'],
        'Cornwall' => ['Bodmin', 'Bude', 'Callington', 'Camborne', 'Falmouth', 'Hayle', 'Helston', 'Launceston', 'Liskeard', 'Looe', 'Newquay', 'Penzance', 'Redruth', 'Saltash', 'St Austell', 'St Ives', 'Truro', 'Wadebridge'],
        'County Durham' => ['Barnard Castle', 'Bishop Auckland', 'Chester-le-Street', 'Consett', 'Darlington', 'Durham', 'Hartlepool', 'Newton Aycliffe', 'Peterlee', 'Seaham', 'Spennymoor', 'Stanley', 'Stockton-on-Tees', 'Sedgefield', 'Ferryhill', 'Crook'],
        'Cumbria' => ['Ambleside', 'Appleby-in-Westmorland', 'Barrow-in-Furness', 'Carlisle', 'Cockermouth', 'Egremont', 'Grange-over-Sands', 'Kendal', 'Keswick', 'Penrith', 'Ulverston', 'Whitehaven', 'Windermere', 'Workington'],
        'Derbyshire' => ['Alfreton', 'Ashbourne', 'Bakewell', 'Belper', 'Bolsover', 'Buxton', 'Chesterfield', 'Derby', 'Dronfield', 'Glossop', 'Heanor', 'Ilkeston', 'Long Eaton', 'Matlock', 'Ripley', 'Swadlincote'],
        'Devon' => ['Axminster', 'Barnstaple', 'Bideford', 'Brixham', 'Crediton', 'Dartmouth', 'Dawlish', 'Exeter', 'Exmouth', 'Honiton', 'Ilfracombe', 'Newton Abbot', 'Okehampton', 'Paignton', 'Plymouth', 'Sidmouth', 'Tavistock', 'Teignmouth', 'Tiverton', 'Torquay', 'Totnes', 'Tiverton'],
        'Dorset' => ['Beaminster', 'Blandford Forum', 'Bournemouth', 'Bridport', 'Christchurch', 'Dorchester', 'Ferndown', 'Gillingham', 'Lyme Regis', 'Poole', 'Shaftesbury', 'Sherborne', 'Sturminster Newton', 'Swanage', 'Verwood', 'Wareham', 'Weymouth', 'Wimborne Minster'],
        'East Riding of Yorkshire' => ['Beverley', 'Bridlington', 'Brough', 'Cottingham', 'Driffield', 'Goole', 'Hedon', 'Hessle', 'Hornsea', 'Howden', 'Kingston upon Hull', 'Market Weighton', 'Pocklington', 'Withernsea'],
        'East Sussex' => ['Battle', 'Bexhill-on-Sea', 'Brighton & Hove', 'Crowborough', 'Eastbourne', 'Hailsham', 'Hastings', 'Heathfield', 'Lewes', 'Newhaven', 'Peacehaven', 'Polegate', 'Rye', 'Seaford', 'Uckfield'],
        'Essex' => ['Basildon', 'Braintree', 'Brentwood', 'Canvey Island', 'Chelmsford', 'Clacton-on-Sea', 'Colchester', 'Epping', 'Grays', 'Harlow', 'Harwich', 'Loughton', 'Maldon', 'Rayleigh', 'Saffron Walden', 'Southend-on-Sea', 'Thurrock', 'Witham'],
        'Gloucestershire' => ['Bishop\'s Cleeve', 'Cheltenham', 'Cirencester', 'Cinderford', 'Coleford', 'Dursley', 'Gloucester', 'Lydney', 'Nailsworth', 'Stonehouse', 'Stroud', 'Tewkesbury', 'Tetbury', 'Winchcombe', 'Wotton-under-Edge'],
        'Greater London' => ['Barking and Dagenham', 'Barnet', 'Bexley', 'Brent', 'Bromley', 'Camden', 'Croydon', 'Ealing', 'Enfield', 'Greenwich', 'Hackney', 'Hammersmith and Fulham', 'Haringey', 'Harrow', 'Havering', 'Hillingdon', 'Hounslow', 'Islington', 'Kensington and Chelsea', 'Kingston upon Thames', 'Lambeth', 'Lewisham', 'Merton', 'Newham', 'Redbridge', 'Richmond upon Thames', 'Southwark', 'Sutton', 'Tower Hamlets', 'Waltham Forest', 'Wandsworth', 'Westminster', 'City of London', 'Romford', 'Harold Hill'],
        'Greater Manchester' => ['Ashton-under-Lyne', 'Bolton', 'Bury', 'Eccles', 'Manchester', 'Oldham', 'Rochdale', 'Salford', 'Stockport', 'Tameside', 'Trafford', 'Wigan'],
        'Hampshire' => ['Aldershot', 'Alton', 'Andover', 'Basingstoke', 'Eastleigh', 'Fareham', 'Farnborough', 'Gosport', 'Havant', 'Lymington', 'Petersfield', 'Portsmouth', 'Romsey', 'Southampton', 'Winchester'],
        'Herefordshire' => ['Hereford', 'Leominster', 'Ross-on-Wye', 'Ledbury', 'Bromyard', 'Kington', 'Credenhill', 'Lugwardine', 'Kingstone', 'Withington', 'Weobley', 'Clehonger', 'Ewyas Harold'],
        'Hertfordshire' => ['St Albans', 'Watford', 'Hemel Hempstead', 'Stevenage', 'Welwyn Garden City', 'Hatfield', 'Hertford', 'Bishop\'s Stortford', 'Hitchin', 'Letchworth Garden City', 'Harpenden', 'Cheshunt', 'Waltham Cross', 'Borehamwood', 'Tring', 'Royston', 'Berkhamsted', 'Bushey', 'Radlett', 'Ware', 'Potters Bar', 'Broxbourne', 'Rickmansworth', 'Buntingford', 'Sawbridgeworth'],
        'Isle of Wight' => ['Ryde', 'Newport', 'Sandown', 'Cowes', 'East Cowes', 'Shanklin', 'Ventnor', 'Yarmouth', 'Brading'],
        'Kent' => ['Maidstone', 'Canterbury', 'Ashford', 'Gillingham', 'Chatham', 'Rochester', 'Dartford', 'Gravesend', 'Tonbridge', 'Tunbridge Wells', 'Sevenoaks', 'Sittingbourne', 'Faversham', 'Herne Bay', 'Whitstable', 'Margate', 'Ramsgate', 'Broadstairs', 'Deal', 'Dover', 'Folkestone', 'Hythe', 'Tenterden', 'Sandwich', 'Swanley'],
        'Lancashire' => ['Preston', 'Blackpool', 'Blackburn', 'Burnley', 'Lancaster', 'Morecambe', 'Chorley', 'Accrington', 'Nelson', 'Colne', 'Leyland', 'Skelmersdale', 'Darwen', 'Fleetwood', 'Lytham St Annes', 'Clitheroe', 'Ormskirk', 'Rawtenstall', 'Bacup', 'Haslingden', 'Garstang', 'Kirkham', 'Longridge', 'Bamber Bridge', 'Carnforth'],
        'Leicestershire' => ['Leicester', 'Loughborough', 'Hinckley', 'Wigston', 'Coalville', 'Melton Mowbray', 'Market Harborough', 'Oadby', 'Earl Shilton', 'Enderby', 'Narborough', 'Shepshed', 'Syston', 'Whetstone', 'Ashby-de-la-Zouch', 'Birstall', 'Mountsorrel', 'Lutterworth', 'Broughton Astley', 'Sileby', 'Groby', 'Anstey', 'Castle Donington', 'Countesthorpe', 'Ibstock', 'Barrow-upon-Soar', 'Kibworth Harcourt', 'Measham', 'Quorn', 'Markfield', 'Fleckney', 'Kirby Muxloe', 'Ratby', 'Desford', 'Stoney Stanton', 'Moira', 'Norris Hill', 'Great Glen', 'Kegworth', 'Bottesford', 'Cosby', 'Asfordby', 'Newbold Verdon', 'East Goscote', 'Donisthorpe', 'Ellistown', 'Bagworth', 'Harby', 'Sapcote', 'Queniborough', 'Woodhouse', 'Ravenstone', 'Market Bosworth', 'Cropston'],
        'Lincolnshire' => ['Lincoln', 'Grimsby', 'Scunthorpe', 'Grantham', 'Boston', 'Spalding', 'Skegness', 'Gainsborough', 'Stamford', 'Louth', 'Sleaford', 'Mablethorpe', 'North Hykeham', 'Bourne', 'Horncastle', 'Holbeach', 'Market Deeping', 'Cleethorpes', 'Wainfleet All Saints', 'Alford', 'Caistor', 'Crowland', 'Sutton on Sea', 'Coningsby', 'Long Sutton', 'Woodhall Spa', 'Kirton in Lindsey', 'Chapel St Leonards'],
        'Merseyside' => ['Liverpool', 'Birkenhead', 'St Helens', 'Southport', 'Wallasey', 'Bebington', 'Bootle', 'Crosby', 'Kirkby', 'Prescot', 'Heswall', 'Maghull', 'Formby', 'Newton-le-Willows', 'Halewood', 'Litherland', 'Haydock', 'West Kirby', 'Hoylake', 'Garswood', 'Billinge', 'Rainford'],
        'Norfolk' => ['Norwich', 'King\'s Lynn', 'Great Yarmouth', 'Thetford', 'Gorleston-on-Sea', 'Dereham', 'Taverham', 'Wymondham', 'North Walsham', 'Downham Market', 'Attleborough', 'Diss', 'Caister-on-Sea', 'Hunstanton', 'Watton', 'Fakenham', 'Cromer', 'Sheringham', 'Swaffham', 'Aylsham', 'Hemsby', 'Hethersett', 'Poringland', 'Dersingham', 'Belton'],
        'North Yorkshire' => ['York', 'Middlesbrough', 'Harrogate', 'Scarborough', 'Redcar', 'Thornaby', 'Northallerton', 'Selby', 'Skipton', 'Whitby', 'Ripon', 'Filey', 'Malton', 'Knaresborough', 'Pickering', 'Richmond', 'Easingwold', 'Stokesley', 'Bedale', 'Tadcaster', 'Boroughbridge', 'Settle', 'Pateley Bridge', 'Leyburn', 'Helmsley', 'Guisborough', 'Loftus', 'Eston', 'Great Ayton', 'Marske-by-the-Sea'],
        'Northamptonshire' => ['Northampton', 'Corby', 'Kettering', 'Wellingborough', 'Rushden', 'Daventry', 'Brackley', 'Desborough', 'Towcester', 'Burton Latimer', 'Raunds', 'Irthlingborough', 'Higham Ferrers', 'Rothwell', 'Thrapston', 'Oundle', 'Earls Barton', 'Brixworth'],
        'Northumberland' => ['Blyth', 'Cramlington', 'Ashington', 'Bedlington', 'Morpeth', 'Berwick-upon-Tweed', 'Hexham', 'Prudhoe', 'Ponteland', 'Stakeford', 'Alnwick', 'Seaton Delaval', 'Newbiggin-by-the-Sea', 'Amble'],
        'Nottinghamshire' => ['Nottingham', 'Mansfield', 'Beeston', 'Sutton-in-Ashfield', 'Arnold', 'Worksop', 'West Bridgford', 'Newark-on-Trent', 'Kirkby-in-Ashfield', 'Carlton', 'Hucknall', 'Eastwood', 'Retford', 'Stapleford', 'Bingham', 'Kimberley', 'Radcliffe-on-Trent', 'Southwell', 'Ollerton', 'Calverton', 'Edwinstowe', 'Rainworth', 'Warsop', 'Clipstone', 'Cotgrave', 'Blidworth', 'Ruddington', 'Keyworth', 'Harworth', 'Balderton'],
        'Oxfordshire' => ['Oxford', 'Banbury', 'Abingdon-on-Thames', 'Bicester', 'Witney', 'Didcot', 'Carterton', 'Kidlington', 'Henley-on-Thames', 'Wallingford', 'Thame', 'Wantage', 'Grove', 'Faringdon', 'Chipping Norton', 'Chinnor', 'Benson', 'Eynsham', 'Wheatley', 'Kennington', 'Woodstock', 'Charlbury', 'Watlington', 'Bampton', 'Deddington'],
        'Rutland' => ['Oakham', 'Uppingham', 'Ketton', 'Ryhall', 'Langham', 'Whissendine', 'Cottesmore', 'Kendrew Barracks', 'Empingham', 'Edith Weston', 'North Luffenham', 'Greetham', 'Exton', 'Great Casterton', 'Market Overton', 'Barrowden', 'Braunston-in-Rutland', 'South Luffenham', 'Essendine', 'Lyddington', 'Manton', 'Belton-in-Rutland', 'Morcott', 'Seaton'],
        'Shropshire' => ['Shrewsbury', 'Telford', 'Oswestry', 'Bridgnorth', 'Ludlow', 'Market Drayton', 'Whitchurch', 'Newport', 'Wem', 'Church Stretton', 'Ellesmere', 'Broseley', 'Bishop\'s Castle', 'Much Wenlock', 'Craven Arms', 'Shifnal', 'Cleobury Mortimer'],
        'Somerset' => ['Bath', 'Weston-super-Mare', 'Taunton', 'Yeovil', 'Bridgwater', 'Frome', 'Portishead', 'Clevedon', 'Burnham-on-Sea', 'Wellington', 'Chard', 'Minehead', 'Street', 'Nailsea', 'Shepton Mallet', 'Glastonbury', 'Wells', 'Midsomer Norton', 'Radstock', 'Ilminster', 'Wincanton', 'Bruton', 'Watchet', 'Crewkerne', 'Highbridge', 'Keynsham', 'Axbridge', 'Castle Cary'],
        'South Yorkshire' => ['Sheffield', 'Doncaster', 'Rotherham', 'Barnsley', 'Wath-upon-Dearne', 'Bentley', 'Wombwell', 'Chapeltown', 'Dinnington', 'Rawmarsh', 'Adwick-le-Street', 'Hoyland', 'Maltby', 'Swinton', 'Penistone', 'Thorne', 'Mexborough', 'Stocksbridge', 'Conisbrough', 'Armthorpe', 'Askern', 'Goldthorpe', 'Edlington', 'Tickhill', 'Cudworth', 'Royston', 'Worsbrough', 'Dodworth', 'Denaby Main', 'Brinsworth'],
        'Staffordshire' => ['Stoke-on-Trent', 'Tamworth', 'Newcastle-under-Lyme', 'Burton upon Trent', 'Stafford', 'Lichfield', 'Cannock', 'Burntwood', 'Kidsgrove', 'Rugeley', 'Leek', 'Biddulph', 'Hednesford', 'Stone', 'Wombourne', 'Uttoxeter', 'Cheadle', 'Great Wyrley', 'Perton', 'Penkridge', 'Codsall', 'Norton Canes', 'Eccleshall', 'Bilbrook', 'Kinver', 'Armitage'],
        'Suffolk' => ['Ipswich', 'Lowestoft', 'Bury St Edmunds', 'Haverhill', 'Felixstowe', 'Sudbury', 'Newmarket', 'Stowmarket', 'Kesgrave', 'Beccles', 'Mildenhall', 'Woodbridge', 'Brandon', 'Hadleigh', 'Leiston', 'Trimley St Mary', 'Halesworth', 'Bungay'],
        'Surrey' => ['Woking', 'Guildford', 'Walton-on-Thames', 'Ewell', 'Esher', 'Camberley', 'Redhill', 'Leatherhead', 'Epsom', 'Weybridge', 'Ashford', 'Egham', 'Staines', 'Farnham', 'Horley', 'Godalming', 'Reigate', 'Caterham', 'Frimley', 'Cobham', 'Dorking', 'Addlestone', 'Ashtead', 'Chertsey', 'Oxted', 'Haslemere', 'Banstead', 'Cranleigh', 'Warlingham', 'Lightwater', 'Hindhead', 'Witley', 'Virginia Water', 'East Horsley', 'Bagshot', 'West Clandon', 'Whitebushes'],
        'Tyne and Wear' => ['Newcastle upon Tyne', 'Sunderland', 'Gateshead', 'South Shields', 'North Shields', 'Washington', 'Jarrow', 'Hebburn', 'Whitley Bay', 'Cramlington', 'Killingworth', 'Wallsend', 'Boldon Colliery', 'East Boldon', 'West Boldon', 'Seaham', 'Ryhope', 'Houghton-le-Spring', 'Felling', 'Birtley', 'Cleadon', 'Monkseaton', 'Tynemouth'],
        'Warwickshire' => ['Nuneaton', 'Rugby', 'Royal Leamington Spa', 'Warwick', 'Bedworth', 'Stratford-upon-Avon', 'Kenilworth', 'Atherstone', 'Polesworth', 'Whitnash', 'Southam', 'Kingsbury', 'Wellesbourne', 'Alcester', 'Coleshill', 'Studley', 'Bulkington', 'Shipston-on-Stour', 'Bidford-on-Avon', 'Long Lawford'],
        'West Midlands' => ['Birmingham', 'Coventry', 'Wolverhampton', 'Solihull', 'West Bromwich', 'Sutton Coldfield', 'Walsall', 'Dudley', 'Halesowen', 'Stourbridge', 'Smethwick', 'Kingswinford', 'Bloxwich', 'Willenhall', 'Bilston', 'Brierley Hill', 'Sedgley', 'Oldbury', 'Tipton', 'Wednesbury', 'Cradley Heath', 'Darlaston', 'Brownhills', 'Pelsall', 'Rowley Regis', 'Bearwood', 'Yew Tree'],
        'West Sussex' => ['Worthing', 'Crawley', 'Bognor Regis', 'Littlehampton', 'Shoreham-by-Sea', 'Horsham', 'Haywards Heath', 'Hurstpierpoint', 'Southwick', 'Selsey', 'Westergate', 'Southwater', 'Storrington', 'West Chiltington Common', 'Billingshurst', 'Steyning', 'East Wittering'],
        'West Yorkshire' => ['Leeds', 'Bradford', 'Huddersfield', 'Wakefield', 'Halifax', 'Batley', 'Dewsbury', 'Keighley', 'Castleford', 'Brighouse', 'Pudsey', 'Morley', 'Pontefract', 'Shipley', 'Bingley', 'Holmfirth', 'Normanton', 'Ossett', 'Yeadon', 'Rothwell', 'Mirfield', 'Horsforth', 'Liversedge', 'Baildon', 'Elland', 'Garforth', 'Ilkley', 'Otley', 'Knottingley', 'Heckmondwike', 'Guiseley', 'Todmorden', 'Cleckheaton', 'Wetherby', 'Featherstone', 'South Elmsall', 'Horbury', 'Kippax', 'Hemsworth', 'South Kirkby', 'Silsden', 'Meltham', 'Burley', 'Haworth', 'Upton', 'Shepley', 'Thornton', 'Ackworth', 'Crofton', 'Ryhill', 'Allerton Bywater', 'Ripponden', 'Boston Spa', 'Sowerby Bridge', 'Skelmanthorpe'],
        'Wiltshire' => ['Swindon', 'Salisbury', 'Trowbridge', 'Chippenham', 'Melksham', 'Devizes', 'Warminster', 'Calne', 'Westbury', 'Corsham', 'Wootton Bassett', 'Amesbury', 'Tidworth', 'Bradford-on-Avon', 'Bulford Camp', 'Marlborough', 'Highworth', 'Wroughton', 'Malmesbury', 'Hilperton', 'Lyneham', 'Ludgershall', 'Purton', 'Cricklade', 'Bulford', 'Pewsey', 'Wilton', 'Box', 'Redlynch', 'Downton', 'Colerne'],
        'Worcestershire' => ['Worcester', 'Redditch', 'Kidderminster', 'Malvern', 'Bromsgrove', 'Evesham', 'Droitwich', 'Stourport-on-Severn', 'Catshill', 'Bewdley', 'Pershore'],
    ],
    'Northern Ireland' => [
        'County Antrim' => ['Belfast', 'Lisburn', 'Newtownabbey', 'Ballymena', 'Carrickfergus', 'Ballymoney', 'Ballyclare'],
        'County Armagh' => ['Lurgan', 'Portadown', 'Newry'],
        'County Down' => ['Bangor', 'Newtownards', 'Downpatrick', 'Holywood'],
        'County Fermanagh' => ['Enniskillen'],
        'County Londonderry' => ['Derry City', 'Coleraine', 'Limavady'],
        'County Tyrone' => ['Omagh', 'Dungannon', 'Strabane', 'Cookstown'],
    ],
    'Scotland' => [
        'Aberdeen City' => ['Aberdeen', 'Cove Bay', 'Dyce', 'Milltimber', 'Peterculter'],
        'Aberdeenshire' => ['Peterhead', 'Fraserburgh', 'Inverurie', 'Stonehaven', 'Ellon'],
        'Angus' => ['Arbroath', 'Forfar', 'Montrose', 'Brechin', 'Carnoustie'],
        'Argyll and Bute' => ['Helensburgh', 'Oban', 'Dunoon', 'Campbeltown', 'Rothesay'],
        'Clackmannanshire' => ['Alloa', 'Tillicoultry', 'Alva', 'Dollar', 'Tullibody'],
        'Dumfries and Galloway' => ['Dumfries', 'Stranraer', 'Annan', 'Lockerbie', 'Castle Douglas'],
        'Dundee City' => ['Dundee', 'Broughty Ferry', 'Invergowrie'],
        'East Ayrshire' => ['Kilmarnock', 'Cumnock', 'Galston', 'Stewarton', 'Hurlford'],
        'East Dunbartonshire' => ['Kirkintilloch', 'Bearsden', 'Milngavie', 'Bishopbriggs', 'Lenzie'],
        'East Lothian' => ['Musselburgh', 'Haddington', 'North Berwick', 'Dunbar', 'Tranent'],
        'East Renfrewshire' => ['Newton Mearns', 'Giffnock', 'Clarkston', 'Thornliebank'],
        'Edinburgh' => ['Edinburgh', 'Leith', 'Portobello', 'Morningside'],
        'Falkirk' => ['Grangemouth', 'Bo\'ness', 'Denny', 'Larbert'],
        'Fife' => ['Dunfermline', 'Kirkcaldy', 'Glenrothes', 'Leven', 'St Andrews'],
        'Glasgow' => ['Glasgow', 'Partick', 'Govan', 'Pollokshields', 'Maryhill'],
        'Highland' => ['Inverness', 'Fort William', 'Nairn', 'Wick', 'Thurso'],
        'Inverclyde' => ['Greenock', 'Gourock', 'Wemyss Bay', 'Port Glasgow', 'Kilmacolm'],
        'Midlothian' => ['Dalkeith', 'Bonnyrigg', 'Penicuik', 'Loanhead', 'Gorebridge'],
        'Moray' => ['Elgin', 'Forres', 'Lossiemouth', 'Buckie', 'Keith'],
        'Western Isles' => ['Stornoway', 'Tarbert', 'Benbecula', 'Lochmaddy', 'Castlebay'],
        'North Ayrshire' => ['Irvine', 'Kilwinning', 'Largs', 'Saltcoats', 'Ardrossan'],
        'North Lanarkshire' => ['Motherwell', 'Airdrie', 'Coatbridge', 'Wishaw', 'Cumbernauld'],
        'Orkney Islands' => ['Kirkwall', 'Stromness', 'St Margaret\'s Hope', 'Dounby'],
        'Perth and Kinross' => ['Perth', 'Kinross', 'Blairgowrie', 'Crieff', 'Pitlochry'],
        'Renfrewshire' => ['Paisley', 'Renfrew', 'Johnstone', 'Erskine', 'Linwood'],
        'Scottish Borders' => ['Galashiels', 'Hawick', 'Kelso', 'Peebles', 'Jedburgh'],
        'Shetland Islands' => ['Lerwick', 'Scalloway', 'Brae', 'Hillswick'],
        'South Ayrshire' => ['Ayr', 'Prestwick', 'Troon', 'Maybole', 'Girvan'],
        'South Lanarkshire' => ['East Kilbride', 'Rutherglen', 'Hamilton', 'Cambuslang', 'Lanark'],
        'Stirling' => ['Bridge of Allan', 'Dunblane', 'Callander', 'Bannockburn', 'Balloch'],
        'West Dunbartonshire' => ['Clydebank', 'Dumbarton', 'Renton', 'Alexandria'],
        'West Lothian' => ['Livingston', 'Bathgate', 'Broxburn', 'Linlithgow', 'Armadale'],
    ],
    'Wales' => [
        'Blaenau Gwent' => ['Ebbw Vale', 'Brynmawr', 'Abertillery', 'Tredegar'],
        'Bridgend' => ['Maesteg', 'Porthcawl', 'Pencoed'],
        'Caerphilly' => ['Blackwood', 'Bargoed', 'Risca', 'Ystrad Mynach'],
        'Cardiff' => ['Llanrumney', 'Splott', 'Llandaff'],
        'Carmarthenshire' => ['Llanelli', 'Carmarthen', 'Ammanford', 'Burry Port'],
        'Ceredigion' => ['Aberystwyth'],
        'Conwy' => ['Llandudno', 'Colwyn Bay', 'Kinmel Bay', 'Abergele'],
        'Denbighshire' => ['Rhyl', 'Prestatyn'],
        'Flintshire' => ['Connah\'s Quay', 'Flint', 'Mold'],
        'Gwynedd' => ['Bangor', 'Caernarfon'],
        'Isle of Anglesey' => ['Holyhead'],
        'Merthyr Tydfil' => ['Merthyr Tydfil'],
        'Monmouthshire' => ['Abergavenny', 'Monmouth', 'Chepstow', 'Caldicot'],
        'Neath Port Talbot' => ['Neath', 'Port Talbot'],
        'Newport' => ['Caerleon'],
        'Pembrokeshire' => ['Milford Haven', 'Haverfordwest'],
        'Powys' => ['Newtown', 'Brecon'],
        'Rhondda Cynon Taf' => ['Tonypandy', 'Aberdare', 'Pontypridd', 'Mountain Ash'],
        'Swansea' => ['Gorseinon', 'Pontarddulais'],
        'Torfaen' => ['Cwmbran', 'Pontypool'],
        'Vale of Glamorgan' => ['Barry', 'Llantwit Major'],
        'Wrexham' => ['Wrexham'],
    ]
];

// Define area-specific sub-areas dataset
$prohandymen_areas = [
    'Belfast' => [
        'New Lodge', 'Tiger\'s Bay', 'Carrick Hill', 'Ardoyne', 'Ligoniel', 'Glenbryn', 'Cavehill', 'Fortwilliam', 'Glengormley', 'Queen\'s Quarter', 
        'Botanic Avenue', 'Lisburn Road', 'Malone', 'Stranmillis', 'Holylands', 'The Markets', 'Donegall Pass', 'The Village', 'Finaghy', 'Taughmonagh', 
        'Belvoir', 'Forestside', 'Upper Malone', 'Ballyhackamore', 'Belmont', 'Rosetta', 'Cregagh', 'Stormont', 'Sydenham', 'Titanic Quarter', 
        'Bloomfield', 'Orangefield', 'Castlereagh', 'Knock', 'Connswater', 'Albertbridge Road', 'Falls Road', 'Shankill Road', 'Gaeltacht Quarter', 
        'Andersonstown', 'Glen Road', 'Upper Springfield', 'Poleglass', 'Twinbrook', 'Colin Glen', 'Turf Lodge', 'Beechmount', 'Suffolk', 
        'Cathedral Quarter', 'Linen Quarter', 'Royal Avenue', 'Sailortown', 'Lisburn', 'Newtownabbey', 'Bangor', 'Carrickfergus', 'Holywood', 
        'Dundonald', 'Glengormley', 'Newtownards', 'Carryduff', 'Dunmurry'
    ],
    'Birkenhead' => [
        'Barnston', 'Bebington', 'Beechwood', 'Bidston', 'Birkenhead', 'Brimstage', 'Bromborough', 'Caldy', 'Clatterbridge', 'Claughton', 
        'Eastham', 'Egremont', 'Ford', 'Frankby', 'Gayton', 'Grange', 'Greasby', 'Heswall', 'Hoylake', 'Irby', 'Landican', 'Larton', 
        'Leasowe', 'Liscard', 'Meols', 'Moreton', 'New Brighton', 'New Ferry', 'Newton', 'Noctorum', 'Oxton', 'Pensby', 'Port Sunlight', 
        'Poulton', 'Prenton', 'Raby Mere', 'Raby', 'Rock Ferry', 'Saughall Massie', 'Seacombe', 'Spital', 'Storeton', 'Thingwall', 
        'Thornton Hough', 'Thurstaston', 'Tranmere', 'Upton', 'Wallasey', 'Wallasey Village', 'West Kirby', 'Woodchurch', 'Woodside'
    ],
    'Bradford' => [
        'Allerton', 'Apperley Bridge', 'Barkerend', 'Belle Vue', 'Bierley', 'Bolton Woods', 'Bowling', 'Bradford Moor', 'Broomfields', 'Buttershaw', 'Clayton', 'Cutler Heights', 'Dudley Hill', 'East Bowling', 'Eccleshill', 'Forster Square', 'Frizinghall', 'Girlington', 'Great Horton', 'Greengates', 'Heaton', 'Holme Wood', 'Idle', 'Laisterdyke', 'Little Germany', 'Little Horton', 'Little London', 'Longlands', 'Low Moor', 'Manningham', 'Odsal', 'Queensbury', 'Ravenscliffe', 'Ripley Ville', 'Sandy Lane', 'Staithgate', 'Thackley', 'Thornbury', 'Thornton', 'Thorpe Edge', 'Tong', 'Trident', 'Tyersal', 'Undercliffe', 'West Bowling', 'Wibsey', 'Wrose', 'Wyke', 'Bingley', 'Shipley', 'Keighley', 'Ilkley', 'Silsden', 'Oxenhope', 'Haworth', 'Denholme', 'Cullingworth', 'Wilsden', 'Menston', 'Burley in Wharfedale', 'Steeton', 'Addingham', 'Oakworth', 'Stanbury', 'Cross Roads', 'Baildon', 'Esholt', 'Cottingley', 'Harden', 'Saltaire'
    ],
    'Bristol' => [
        'Arnos Vale', 'Ashley Down', 'Ashton Gate', 'Ashton Vale', 'Avonmouth', 'Baptist Mills', 'Barrs Court', 'Barton Hill', 'Bedminster', 'Bedminster Down', 'Begbrook', 'Bishopston', 'Bishopsworth', 'Blaise Hamlet', 'Botany Bay', 'Bower Ashton', 'Brentry', 'Brislington', 'Broadmead', 'Broomhill', 'Canons Marsh', 'Chester Park', 'Clay Hill', 'Clifton', 'Coombe Dingle', 'Cotham', 'Crew\'s Hole', 'Crofts End', 'Downend', 'Eastville', 'Easton', 'Emersons Green', 'Failand', 'Filton', 'Filwood Park', 'Fishponds', 'Frampton Cotterell', 'Golden Hill', 'Greenbank', 'Hambrook', 'Hanham', 'Hartcliffe', 'Headley Park', 'Henbury', 'Hengrove', 'Henleaze', 'Hillfields', 'Horfield', 'Hotwells', 'Kensington Park', 'Keynsham', 'Kingsdown', 'Kingswood', 'Knowle', 'Knowle West', 'Lawrence Hill', 'Lawrence Weston', 'Lewin\'s Mead', 'Lockleaze', 'Lodge Hill', 'Longwell Green', 'Long Ashton', 'Mangotsfield', 'Mayfield Park', 'Monks Park', 'Montpelier', 'Moorfields', 'Nailsea', 'Netham', 'Newtown', 'North Common', 'Oldland Common', 'Patchway', 'Pill', 'Portishead', 'Pucklechurch', 'Redcliffe', 'Redfield', 'Redland', 'Ridgeway', 'Sea Mills', 'Severn Beach', 'Shirehampton', 'Sneyd Park', 'Southmead', 'Southville', 'Speedwell', 'Spike Island', 'St Agnes', 'St Andrews', 'St Anne\'s', 'St George', 'St Jude\'s', 'St Paul\'s', 'St Philip\'s Marsh', 'St Werburgh\'s', 'Staple Hill', 'Stapleton', 'Stockwood', 'Stoke Bishop', 'Stokes Croft', 'Stoke Gifford', 'Stoke Lodge', 'Thornbury', 'Totterdown', 'Two Mile Hill', 'Tyndalls Park', 'Upper Knowle', 'Victoria Park', 'Warmley', 'Westbury on Trym', 'Westbury Park', 'Whitchurch', 'Whitehall', 'Willsbridge', 'Windmill Hill', 'Winterbourne', 'Withywood', 'Yate'
    ],
    'Cardiff' => [
        'Adamsdown', 'Birchgrove', 'Butetown', 'Caerau', 'Canton', 'Cardiff Bay', 'Cardiff Gate', 'Cathays', 'Coryton', 'Creigiau', 'Cyncoed', 'Danescourt', 'Ely', 'Fairwater', 'Gabalfa', 'Grangetown', 'Heath', 'Lisvane', 'Llandaff', 'Llandaff North', 'Llanedeyrn', 'Llanishen', 'Llanrumney', 'Maindy', 'Morganstown', 'Old St Mellons', 'Pentrebane', 'Pentwyn', 'Pentyrch', 'Penylan', 'Plasnewydd', 'Pontcanna', 'Pontprennau', 'Radyr', 'Rhiwbina', 'Riverside', 'Roath', 'Rumney', 'Splott', 'St Fagans', 'St Mellons', 'Thornhill', 'Tongwynlais', 'Tremorfa', 'Trowbridge', 'Whitchurch'
    ],
    'Coventry' => [
        'Alderman\'s Green', 'Allesley', 'Allesley Green', 'Allesley Park', 'Ash Green', 'Ball Hill', 'Bannerbrook Park', 'Bell Green', 'Binley', 'Bishopsgate Green', 'Brownshill Green', 'Canley', 'Canley Gardens', 'Cannon Park', 'Chapelfields', 'Cheylesmore', 'Church End', 'Clifford Park', 'Copsewood', 'Coundon', 'Courthouse Green', 'Daimler Green', 'Earlsdon', 'Eastern Green', 'Edgwick', 'Ernesford Grange', 'Finham', 'Fenside', 'Foleshill', 'Gibbet Hill', 'Gosford Green', 'Great Heath', 'Hearsall Common', 'Henley Green', 'Hillfields', 'Holbrooks', 'Keresley', 'Little Heath', 'Longford', 'Middle Stoke', 'Monks Park', 'Mount Nod', 'Nailcote Grange', 'Pinley', 'Potters Green', 'Radford', 'Spon End', 'Stoke', 'Stoke Heath', 'Stoke Aldermoor', 'Stivichall', 'Tanyard Farm', 'Tile Hill', 'Toll Bar End', 'Upper Stoke', 'Victoria Farm', 'Walsgrave-on-Sowe', 'Westwood Heath', 'Whitley', 'Whitmore Park', 'Whoberley', 'Willenhall', 'Wood End', 'Woodway Park', 'Wyken'
    ],
    'Derby' => [
        'Allenton', 'Allestree', 'Alvaston', 'Boulton', 'California', 'Cathedral Quarter', 'Chaddesden', 'Chellaston', 'Crewton', 'Darley Abbey', 'Heatherton Village', 'Litchurch', 'Little Chester', 'Littleover', 'Mackworth', 'Markeaton', 'Mickleover', 'Normanton', 'Oakwood', 'Osmaston', 'Pear Tree', 'Rose Hill', 'Arboretum', 'Spondon', 'Sinfin', 'Stenson Fields', 'New Zealand', 'Kingsway', 'Breadsall Hilltop', 'Cavendish', 'Litchurch', 'St Peter\'s Quarter', 'Intu Derby', 'Quarndon', 'Duffield', 'Borrowash', 'Little Eaton', 'Ockbrook', 'Findern', 'Burnaston', 'Thulston Fields'
    ],
    'Edinburgh' => [
        'Abbeyhill', 'Alnwickhill', 'Ardmillan', 'Baberton', 'Balerno', 'Balgreen', 'Bankhead', 'Barnton', 'Beechmount', 'Bingham', 'Blackford', 'Blackhall', 'Bonaly', 'Bonnington', 'Burghmuirhead', 'Braepark', 'Broomhouse', 'Broughton', 'Brunstane', 'Bruntsfield', 'Bughtlin', 'Burdiehouse', 'The Calders', 'Cameron Toll', 'Cammo', 'The Canongate', 'Canonmills', 'Chesser', 'Church Hill', 'Clermiston', 'Colinton', 'Comely Bank', 'Comiston', 'Corstorphine', 'Craigcrook', 'Craigentinny', 'Craigleith', 'Craiglockhart', 'Craigmillar', 'Cramond', 'Crewe Toll', 'Currie', 'Curriehill', 'Dalmeny', 'Dalry', 'Davidson\'s Mains', 'Dean Village', 'Drumbrae', 'Drylaw', 'Duddingston', 'Dumbiedykes', 'East Craigs', 'East Pilton', 'Eastfield', 'Edinburgh Park', 'Fairmilehead', 'Ferniehill', 'Firrhill', 'Forrester', 'Fountainbridge', 'Gilmerton', 'Gogar', 'Gogarloch', 'Goldenacre', 'Gorgie', 'The Grange', 'Grassmarket', 'Granton', 'Greenbank', 'Greendykes', 'Greenhill', 'Haymarket', 'Hermiston', 'Holy Corner', 'Holyrood', 'Holyrood Park', 'Ingliston', 'Inverleith', 'Jock\'s Lodge', 'Joppa', 'Juniper Green', 'Kaimes', 'Kingsknowe', 'Kirkliston', 'Lauriston', 'Leith', 'Liberton', 'Little France', 'Lochend', 'Lochrin', 'Longstone', 'Marchmont', 'Maybury', 'Mayfield', 'Meadowbank', 'The Meadows', 'Merchiston', 'Moredun', 'Morningside', 'Mortonhall', 'Mountcastle', 'Muirhouse', 'Murrayfield', 'New Town', 'Newbridge', 'Newcraighall', 'Newhaven', 'Newington', 'Niddrie', 'Northfield', 'Old Town', 'Oxgangs', 'Parkgrove', 'Parkhead', 'Piershill', 'Pilrig', 'Pilton', 'Polwarth', 'Portobello', 'Powderhall', 'Prestonfield', 'Ratho', 'Ratho Station', 'Ravelston', 'Redford', 'Restalrig', 'Riccarton', 'Roseburn', 'Saughton', 'Sciennes', 'Seafield', 'Shandon', 'Sighthill', 'Silverknowes', 'Slateford', 'South Gyle', 'South Queensferry', 'Stenhouse', 'Stockbridge', 'Swanston', 'Tollcross', 'Torphin', 'Trinity', 'Turnhouse', 'Tynecastle', 'Warriston', 'Waterfront Edinburgh', 'West Coates', 'West Craigs', 'West End', 'West Pilton', 'Wester Broom', 'Wester Hailes', 'Western Harbour'
    ],
    'Glasgow' => [
        'Abbeyhill', 'Alnwickhill', 'Ardmillan', 'Baberton', 'Balerno', 'Balgreen', 'Bankhead', 'Barnton', 'Beechmount', 'Bingham', 'Blackford', 'Blackhall', 'Bonaly', 'Bonnington', 'Burghmuirhead', 'Braepark', 'Broomhouse', 'Broomhill', 'Budhill', 'Cadder', 'Calton', 'Camlachie', 'Carmyle', 'Carntyne', 'Colston', 'Cowcaddens', 'Cowlairs', 'Craigend', 'Cranhill', 'Dalmarnock', 'Dennistoun', 'Dowanhill', 'Drumchapel', 'Easterhouse', 'Firhill', 'Gallowgate', 'Garnethill', 'Garrowhill', 'Garscadden', 'Garthamlock', 'Germiston', 'Gilshochill', 'Greenfield', 'Haghill', 'Hamiltonhill', 'High Possil', 'High Ruchill', 'Hillhead', 'Hogganfield', 'Hyndland', 'Jordanhill', 'Kelvinbridge', 'Kelvindale', 'Kelvingrove', 'Kelvinhaugh', 'Kelvinside', 'Knightswood', 'Lambhill', 'Lancefield', 'Lightburn', 'Lilybank', 'Maryhill', 'Maryhill Park', 'Merchant City', 'Millerston', 'Milton', 'Mount Vernon', 'Netherton', 'Newbank', 'North Kelvinside', 'Park District', 'Parkhead', 'Parkhouse', 'Partick', 'Partickhill', 'Port Dundas', 'Possilpark', 'Provanhall', 'Provanmill', 'Queenslie', 'Riddrie', 'Robroyston', 'Royston', 'Ruchazie', 'Ruchill', 'Sandyford', 'Sandyhills', 'Scotstoun', 'Scotstounhill', 'Shettleston', 'Sighthill', 'Springboig', 'Springburn', 'Springhill', 'Stobcross', 'Stobhill', 'Summerston', 'Swinton', 'Temple', 'Tollcross', 'Townhead', 'Wallacewell', 'Wellhouse', 'Whiteinch', 'Woodlands', 'Woodside', 'Yoker', 'Yorkhill', 'Arden', 'Auldhouse', 'Battlefield', 'Bellahouston', 'Cardonald', 'Carmunnock', 'Carnwadric', 'Castlemilk', 'Cathcart', 'Cessnock', 'Corkerhill', 'Cowglen', 'Craigton', 'Croftfoot', 'Crookston', 'Crosshill', 'Crossmyloof', 'Darnley', 'Deaconsbank', 'Drumoyne', 'Dumbreck', 'Eastwood', 'Fairfield', 'Govan', 'Govanhill', 'Gorbals', 'Halfway', 'Hillington', 'Hillpark', 'Househillwood', 'Hutchesontown', 'Ibrox', 'Jenny Lind', 'Kennishead', 'King\'s Park', 'Kingston', 'Kinning Park', 'Langlands', 'Langshot', 'Langside', 'Laurieston', 'Linthouse', 'Mansewood', 'Mavisbank', 'Merrylee', 'Moorepark', 'Mosspark', 'Mount Florida', 'Muirend', 'Newlands', 'Nitshill', 'Oatlands', 'Parkhouse', 'Pollok', 'Pollokshaws', 'Pollokshields', 'Polmadie', 'Port Eglinton', 'Priesthill', 'Queen\'s Park', 'Rosshall', 'Roughmussel', 'Shawlands', 'Shieldhall', 'Simshill', 'South Nitshill', 'Southpark Village', 'Strathbungo', 'Summertown', 'Toryglen', 'Tradeston', 'Wearieston'
    ],
    'Hull' => [
        'Bilton Grange Estate', 'Bransholme', 'Drypool', 'Garrison Side', 'The Groves', 'Garden Village', 'Kingswood', 'Longhill', 'Marfleet', 'Greatfield Estate', 'Preston Road Estate', 'Southcoates', 'Stoneferry', 'Summergangs', 'Sutton Ings', 'Sutton-on-Hull', 'Victoria Dock Village', 'Wilmington', 'Anlaby Common', 'Anlaby Park', 'East Ella', 'The Avenues', 'Dairycoates', 'Gipsyville', 'Inglemire', 'Newland', 'Newland Park', 'North Hull Estate', 'Orchard Park Estate', 'Sculcoates', 'Stepney', 'Anlaby', 'Kirk Ella', 'Willerby', 'Bilton', 'Cottingham', 'Dunswell', 'Hedon', 'Hessle', 'Preston', 'Salt End', 'Swanland', 'Wawne'
    ],
    'Islington' => [
        'Angel', 'Archway', 'Barnsbury', 'Canonbury', 'Clerkenwell', 'Farringdon', 'Finsbury', 'Finsbury Park', 'Highbury', 'Highbury Fields', 'Highbury Hill', 'Holloway', 'Lower Holloway', 'Mildmay', 'Nag\'s Head', 'Newington Green', 'Pentonville', 'St Luke\'s', 'St Mary\'s', 'Tufnell Park', 'Upper Holloway', 'Islington', 'De Beauvoir Town', 'Caledonian Road', 'Essex Road', 'King\'s Cross', 'Crouch Hill'
    ],
    'Leeds' => [
        'Adel', 'Alwoodley', 'Armley', 'Beeston', 'Belle Isle', 'Bramham', 'Bramhope', 'Bramley', 'Burley', 'Chapel Allerton', 'Churwell', 'Colton', 'Cookridge', 'Cross Gates', 'Farsley', 'Fearnville', 'Garforth', 'Gildersome', 'Gipton', 'Guiseley', 'Halton', 'Harehills', 'Harewood', 'Headingley', 'Holbeck', 'Holt Park', 'Hunslet', 'Hyde Park', 'Killingbeck', 'Kirkstall', 'Lawnswood', 'Meanwood', 'Middleton', 'Moortown', 'Morley', 'Oakwood', 'Otley', 'Pudsey', 'Rawdon', 'Rodley', 'Rothwell', 'Roundhay', 'Seacroft', 'Shadwell', 'Stanningley', 'Temple Newsam', 'Weetwood', 'West Park', 'Whinmoor', 'Whitkirk', 'Wortley', 'Woodhouse', 'Yeadon'
    ],
    'Leicester' => [
        'Aylestone', 'Beaumont Leys', 'Belgrave', 'Birstall', 'Blackfriars', 'Braunstone', 'Braunstone Town', 'Clarendon Park', 'Crown Hills', 'Evington', 'Eyres Monsell', 'Frog Island', 'Goodwood', 'Hamilton', 'Humberstone', 'Knighton', 'Newfoundpool', 'New Parks', 'North Evington', 'Rowlatts Hill', 'Rushey Mead', 'Southfields', 'Spinney Hills', 'Stoneygate', 'Thurnby Lodge', 'Thurncourt', 'Westcotes', 'West End', 'Western Park', 'Wigston', 'Woodgate'
    ],
    'Liverpool' => [
        'Aigburth', 'Allerton', 'Anfield', 'Belle Vale', 'Broadgreen', 'Canning', 'Childwall', 'Chinatown', 'Clubmoor', 'Croxteth', 'Dingle', 'Edge Hill', 'Everton', 'Fairfield', 'Fazakerley', 'Garston', 'Gateacre', 'Georgian Quarter', 'Gillmoss', 'Grassendale', 'Hunts Cross', 'Kensington', 'Kirkdale', 'Knotty Ash', 'Liverpool City Centre', 'Mossley Hill', 'Netherley', 'Norris Green', 'Old Swan', 'Orrell Park', 'Sefton Park', 'Speke', 'St Michael\'s Hamlet', 'Stanley', 'Toxteth', 'Tuebrook', 'Vauxhall', 'Walton', 'Warbreck', 'Wavertree', 'West Derby', 'Woolton'
    ],
    'London' => [
        'Acton', 'Anerley', 'Archway', 'Balham', 'Barking', 'Battersea', 'Beckenham', 'Belsize Park', 'Bethnal Green', 'Blackheath', 'Borough', 'Brixton', 'Bromley', 'Camberwell', 'Camden Town', 'Canning Town', 'Catford', 'Chalk Farm', 'Charlton', 'Chelsea', 'Chingford', 'Chiswick', 'Clapham', 'Cockfosters', 'Colliers Wood', 'Cricklewood', 'Croydon', 'Crystal Palace', 'Dalston', 'Deptford', 'Dollis Hill', 'Dulwich', 'Ealing', 'Earls Court', 'East Finchley', 'East Ham', 'Edgware', 'Edmonton', 'Elephant and Castle', 'Eltham', 'Enfield', 'Euston', 'Farringdon', 'Finchley', 'Finsbury', 'Finsbury Park', 'Forest Gate', 'Forest Hill', 'Fulham', 'Golders Green', 'Greenford', 'Greenwich', 'Hackney', 'Hammersmith', 'Hampstead', 'Hanwell', 'Haringey', 'Harrow', 'Hatch End', 'Hayes', 'Hendon', 'Herne Hill', 'Highbury', 'Highgate', 'Holloway', 'Homerton', 'Hornchurch', 'Hornsey', 'Hounslow', 'Ilford', 'Isle of Dogs', 'Islington', 'Kennington', 'Kensal Green', 'Kensington', 'Kentish Town', 'Kenton', 'Kew', 'Kilburn', 'Kings Cross', 'Kingsbury', 'Kingston upon Thames', 'Ladywell', 'Lambeth', 'Lee', 'Lewisham', 'Leyton', 'Leytonstone', 'Maida Vale', 'Manor Park', 'Mill Hill', 'Mitcham', 'Morden', 'Mortlake', 'Muswell Hill', 'Neasden', 'New Cross', 'New Malden', 'Newham', 'Norbury', 'North Finchley', 'Northolt', 'Norwood', 'Notting Hill', 'Nunhead', 'Paddington', 'Palmers Green', 'Peckham', 'Penge', 'Perivale', 'Pimlico', 'Pinner', 'Plaistow', 'Poplar', 'Putney', 'Rainham', 'Rayners Lane', 'Redbridge', 'Richmond', 'Roehampton', 'Rotherhithe', 'Ruislip', 'Seven Sisters', 'Shepherd\'s Bush', 'Shoreditch', 'Sidcup', 'Silvertown', 'Soho', 'South Norwood', 'Southall', 'Southbank', 'Southfields', 'Southgate', 'St John\'s Wood', 'Streatham', 'Stratford', 'Sudbury', 'Surbiton', 'Sutton', 'Swiss Cottage', 'Sydenham', 'Thamesmead', 'Tooting', 'Tottenham', 'Totteridge', 'Tower Hill', 'Tufnell Park', 'Turnpike Lane', 'Twickenham', 'Upminster', 'Uxbridge', 'Vauxhall', 'Walthamstow', 'Wandsworth', 'Wanstead', 'Wapping', 'Wealdstone', 'Wembley', 'West Drayton', 'West Ham', 'West Hampstead', 'West Kensington', 'West Norwood', 'West Wickham', 'Westminster', 'Whitechapel', 'Willesden', 'Wimbledon', 'Winchmore Hill', 'Woolwich', 'Wood Green', 'Woodford', 'Woolwich'
    ],
    'Luton' => [
        'Arbury', 'Biscot', 'Bramingham', 'Challney', 'Dallow', 'Farley Hill', 'High Town', 'Leagrave', 'Luton Town Centre', 'New Town', 'Park Town', 'South Luton', 'Stopsley', 'Sundon Park', 'Wardown Park', 'West Luton', 'Woodside'
    ],
    'Manchester' => [
        'Ancoats', 'Ardwick', 'Ashton-under-Lyne', 'Baguley', 'Belle Vue', 'Chorlton', 'Chorlton-cum-Hardy', 'Clayton', 'Crumpsall', 'Deansgate', 'Fallowfield', 'Gorton', 'Harpurhey', 'Heaton Mersey', 'Heaton Moor', 'Heaton Park', 'Levenshulme', 'Longsight', 'Manchester City Centre', 'Moss Side', 'Moston', 'Northern Quarter', 'Old Trafford', 'Ordsall', 'Pendlebury', 'Platt Fields', 'Prestwich', 'Radcliffe', 'Rusholme', 'Salford', 'Salford Quays', 'Shambles Square', 'South Manchester', 'Spinningfields', 'Stretford', 'Swinton', 'The Village', 'Wythenshawe', 'Whalley Range', 'Withington', 'Woodhouse Park'
    ],
    'Miltonkeynes' => [
        'Bletchley', 'Bradwell', 'Campbell Park', 'Chesney\'s', 'Central Milton Keynes', 'Crownhill', 'Downhead Park', 'Eaglestone', 'Fishermead', 'Fullers Slade', 'Green Park', 'Hodge Lea', 'Kents Hill', 'Kiln Farm', 'Leadenhall', 'Loughton', 'Milton Keynes Village', 'New Bradwell', 'Old Stratford', 'Olney', 'Shenley Church End', 'Shenley Lodge', 'Stony Stratford', 'Tattenhoe', 'Wavendon', 'Westcroft', 'Willen', 'Woolstone'
    ],
    'Newport' => [
        'Alway', 'Bassaleg', 'Beechwood', 'Caerleon', 'Cleppa Park', 'Clytha', 'Corporation Road', 'East Newport', 'Maesglas', 'Malpas', 'Mynydd Isa', 'Newport City Centre', 'Pillgwenlly', 'Ringland', 'Rhiwderin', 'Somerton', 'St Julians', 'Tredegar Park', 'Victoria', 'Western Avenue', 'Woodland View'
    ],
    'Northampton' => [
        'Abington', 'Barton Seagrave', 'Bozeat', 'Billing', 'Blisworth', 'Brixworth', 'Castle', 'Collingtree', 'East Hunsbury', 'Ecton', 'Far Cotton', 'Great Houghton', 'Kingsthorpe', 'Kingsley', 'Little Houghton', 'Moulton', 'Naseby', 'Northampton Town Centre', 'Pitsford', 'Poets Corner', 'Rushmere', 'Semilong', 'Southfields', 'Spring Park', 'St James', 'St Giles', 'St Luke\'s', 'Upton', 'Wootton', 'West Hunsbury', 'Weston Favell', 'Wootton Fields'
    ],
    'Nottingham' => [
        'Abbey Park', 'Aspley', 'Beeston', 'Bestwood', 'Bilborough', 'Carlton', 'City Centre', 'Clifton', 'Dunkirk', 'Forest Fields', 'Gedling', 'Hucknall', 'Lenton', 'Mapperley', 'Nuthall', 'Radford', 'Ruddington', 'Sherwood', 'St Ann\'s', 'The Meadows', 'West Bridgford', 'Wollaton', 'Sneinton', 'Trent Bridge', 'Nottingham Forest', 'Basford', 'Bingham', 'Edwalton', 'Bramcote'
    ],
    'Portsmouth' => [
        'Alverstoke', 'Baffins', 'Copnor', 'Drayton', 'Eastney', 'Fratton', 'Hilsea', 'Hodges Road', 'Landport', 'Milton', 'North End', 'Old Portsmouth', 'Portsmouth City Centre', 'Southsea', 'Stubbington', 'The Hard', 'West End', 'Wickham'
    ],
    'Preston' => [
        'Avenham', 'Bamber Bridge', 'Cottam', 'Deepdale', 'Fulwood', 'Fishwick', 'Goosnargh', 'Grimsargh', 'Harris Park', 'Ingol', 'Kirkham', 'Leyland', 'Longton', 'Lytham', 'Moss Side', 'Newsham', 'Ribbleton', 'Sharoe Green', 'South Ribble', 'St. Matthew\'s', 'Tulketh', 'University Quarter', 'Preston City Centre', 'Penwortham', 'Walton-le-Dale', 'Whitefield', 'Whittingham'
    ],
    'Reading' => [
        'Caversham', 'Central Reading', 'Chatham Place', 'Earley', 'Emmer Green', 'Greyfriars', 'Katesgrove', 'Kenavon Drive', 'Lower Earley', 'Mapledurham', 'Newtown', 'Norcot', 'Reading Town Centre', 'Southcote', 'The University Area', 'Tilehurst', 'Whitley', 'Woodley'
    ],
    'Sheffield' => [
        'Abbeydale', 'Aston', 'Attercliffe', 'Broomhill', 'Burngreave', 'Broomhill', 'Carterknowle', 'Darnall', 'Ecclesall', 'Firth Park', 'Fulwood', 'Gleadless', 'Gleadless Valley', 'Greystones', 'Hackenthorpe', 'Hillsborough', 'Highfield', 'Manor', 'Nether Edge', 'Netherthorpe', 'Owlerton', 'Park Hill', 'Pitsmoor', 'Sharrow', 'Sheffield City Centre', 'South Anston', 'Stannington', 'Stocksbridge', 'Totley', 'Walkley', 'Woodhouse'
    ],
    'Southampton' => [
        'Basset', 'Bitterne', 'Bitterne Park', 'Central Southampton', 'Chilworth', 'Eastleigh', 'Hedge End', 'Highfield', 'Millbrook', 'Moorlands', 'Netley Abbey', 'Northam', 'Ocean Village', 'Portswood', 'Redbridge', 'Shirley', 'Southampton City Centre', 'Swaythling', 'Totton', 'Upper Shirley', 'West End', 'West Quay', 'Weston', 'Woolston'
    ],
    'Southend' => [
        'Admirals Walk', 'Ashingdon', 'Eastwood', 'Fairleigh', 'Great Wakering', 'Hamlet Court Road', 'Kursaal', 'Leigh-on-Sea', 'Prittlewell', 'Southend Central', 'Southend-on-Sea', 'Southchurch', 'Shoeburyness', 'Thorpe Bay', 'Westcliff-on-Sea', 'West Shoebury'
    ],
    'Stoke' => [
        'Abbey Hulton', 'Burslem', 'Chell', 'Chesterton', 'Fenton', 'Hanley', 'Heron Cross', 'Longton', 'Meir', 'Normacot', 'Oakhill', 'Penkhull', 'Sandon', 'Sneyd Green', 'Tunstall', 'Trentham', 'Werrington', 'Weston Coyney', 'Wood Lane'
    ],
    'Sunderland' => [
        'Ashbrooke', 'Barnes', 'Castletown', 'City Centre', 'Doxford Park', 'Farringdon', 'Grangetown', 'Hendon', 'Hylton Castle', 'Monkwearmouth', 'Moorside', 'Pallion', 'Pennywell', 'Red House', 'Ryhope', 'Seaburn', 'Silksworth', 'South Hylton', 'Southwick', 'Springwell', 'Thornhill', 'Thorney Close', 'Town End Farm', 'Wearside', 'Whitburn'
    ],
    'Swansea' => [
        'Birchgrove', 'Blackpill', 'Bonymaen', 'Clydach', 'Cwmbwrla', 'Fforestfach', 'Gorseinon', 'Gowerton', 'Killay', 'Landore', 'Llansamlet', 'Morriston', 'Mumbles', 'Mynyddbach', 'Penlan', 'Penllergaer', 'Port Tennant', 'Sandfields', 'Singleton Park', 'Sketty', 'St Thomas', 'Townhill', 'Uplands', 'Waunarlwydd', 'West Cross'
    ],
    'Wolverhampton' => [
        'All Saints', 'Ashmore Park', 'Bilston', 'Blakenhall', 'Bradmore', 'Bushbury', 'Codsall', 'Compton', 'Dovecotes', 'Ettingshall', 'Fallings Park', 'Finchfield', 'Goldthorn Park', 'Heath Town', 'Low Hill', 'Lanesfield', 'Merry Hill', 'Oxley', 'Parkfields', 'Pendeford', 'Penn', 'Portobello', 'Spring Vale', 'Stowheath', 'Tettenhall', 'Tettenhall Wood', 'Wednesfield', 'Whitmore Reans'
    ],
    'Birmingham' => [
        'Acocks Green', 'Aston', 'Bartley Green', 'Balsall Heath', 'Billesley', 'Birchfield', 'Bordesley Green', 'Bournbrook', 'Bournville', 'Castle Bromwich', 'Cotteridge', 'Digbeth', 'Edgbaston', 'Erdington', 'Frankley', 'Garretts Green', 'Great Barr', 'Hall Green', 'Handsworth', 'Harborne', 'Hodge Hill', 'Jewellery Quarter', 'Kings Heath', 'Kings Norton', 'Ladywood', 'Longbridge', 'Lozells', 'Moseley', 'Nechells', 'Newtown', 'Northfield', 'Perry Barr', 'Perry Beeches', 'Quinton', 'Saltley', 'Selly Oak', 'Sheldon', 'Small Heath', 'Sparkbrook', 'Sparkhill', 'Stechford', 'Stirchley', 'Stockland Green', 'Sutton Coldfield', 'Tyseley', 'Ward End', 'Weoley Castle', 'Winson Green', 'Witton', 'Yardley'
    ],
    'Norwich' => [
        'Bowthorpe', 'Catton Grove', 'Costessey', 'Cringleford', 'Eaton', 'Golden Triangle', 'Heartsease', 'Hellesdon', 'Lakenham', 'Mile Cross', 'New Costessey', 'Old Catton', 'Sprowston', 'Taverham', 'Thetford Road', 'Thorpe Hamlet', 'Thorpe St Andrew', 'Tuckswood', 'Wensum', 'West Earlham'
    ],
];

// [internal_links]
// [internal_links area="belfast"]

// Slug generation function
function prohandymen_slugify($text) {
    // Remove apostrophes first
    $text = str_replace("'", "", $text);
    // Replace non-letter/non-digit characters with hyphens
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    // Transliterate to ASCII
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    // Remove unwanted characters
    $text = preg_replace('~[^-\w]+~', '', $text);
    // Trim hyphens
    $text = trim($text, '-');
    // Collapse multiple hyphens
    $text = preg_replace('~-+~', '-', $text);
    // Convert to lowercase
    return strtolower($text);
}

function prohandymen_internal_links_shortcode($atts) {
    global $prohandymen_locations, $prohandymen_areas;

    // Parse shortcode attributes
    $atts = shortcode_atts(array(
        'area' => '',
    ), $atts);

    // Handle area-specific links
    if (!empty($atts['area'])) {
        $area_name = ucfirst(strtolower($atts['area'])); // Normalize area name
        if (isset($prohandymen_areas[$area_name])) {
            $output = '<ul class="area-links">';
            foreach ($prohandymen_areas[$area_name] as $sub_area) {
//                 $area_slug = prohandymen_slugify($area_name);
                $sub_area_slug = prohandymen_slugify($sub_area);
                $url = home_url("/near-me/{$sub_area_slug}");
                $output .= "<li><a href='{$url}'>{$sub_area}</a></li>";
            }
            $output .= '</ul>';
            return $output;
        }
        return ''; // Return empty if area not found
    }

    // Existing logic for country/state/city links
    if (is_front_page()) {
        $output = '<ul class="area-links">';
        foreach ($prohandymen_locations as $country => $states) {
            $slug = prohandymen_slugify($country);
            $output .= '<li><a href="' . home_url('/near-me/' . $slug) . '">' . $country . '</a></li>';
        }
        return $output . '</ul>';
    }

    // Parse current URL path
    $current_path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
    $segments = explode('/', $current_path);

    // Handle near-me pages
    if (isset($segments[0]) && $segments[0] === 'near-me') {
        array_shift($segments);

        if (count($segments) >= 1) {
            $request_slug = $segments[0];
            
            // Check country
            foreach ($prohandymen_locations as $country => $states) {
                if (prohandymen_slugify($country) === $request_slug) {
                    $output = '<ul class="area-links">';
                    foreach ($states as $state => $cities) {
                        $state_slug = prohandymen_slugify($state);
                        $output .= '<li><a href="' . home_url('/near-me/' . $state_slug) . '">' . $state . '</a></li>';
                    }
                    return $output . '</ul>';
                }
            }

            // Check state
            foreach ($prohandymen_locations as $country => $states) {
                foreach ($states as $state => $cities) {
                    if (prohandymen_slugify($state) === $request_slug) {
                        $output = '<ul class="area-links">';
                        foreach ($cities as $city) {
                            $city_slug = prohandymen_slugify($city);
                            $output .= '<li><a href="' . home_url('/near-me/' . $request_slug . '/' . $city_slug) . '">' . $city . '</a></li>';
                        }
                        return $output . '</ul>';
                    }
                }
            }
        }
    }
    
    return '';
}

// Register the shortcode
add_shortcode('internal_links', 'prohandymen_internal_links_shortcode');

